# giải thích
phần movie chỉ có page 1 nhưng không có page 2 vì trong quá trình build bị lỗi, hiện tại lượng code đã khá lớn không thể sửa lại được